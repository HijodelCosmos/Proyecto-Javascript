
/*Este programa consiste en aplicar el test de ansiedad de hamilton(HARS) a un paciente, el profesional va a ir completando
 los datos del paciente durante una entrevista. Comenzado el test, va completando el grado de intensidad que percibe (de 0 a 4)
 en los 14 items que corresponden a distintos sintomas de ansiedad. EL test es muy simple ya que su principal funcionalidad
 es para seguir el progreso de las terapias o tener una vision global del estadao del paciente
 Los items 1,2,3,4,5,6 y 14 corresponden a sintomaas psiquicos; y los items 7,8,9,10,11,12 y 13 son sintomas somáticos
 El programa suma las respuestas y devuelve el grado de gravedad de ansiedad y la necesidad de tratamiento*/


/*Creadores de objeto*/
function PlanillaDePaciente(nombre,edad,sexo,resultadosEscalaHars){
    this.nombre=nombre;
    this.edad=edad;
    this.sexo=sexo;
    this.resultadosEscalaHars=resultadosEscalaHars; /*Propiedad privada y corresponde al resultado total del test*/
}

function EscalaHars(fechaDeTesteo,puntajeDeAnsiedadPsiquica,puntajeDeAnsiedadSomatica,ansiedadTotal){
    this.fecha=fechaDeTesteo;
    this.aPsiquica=puntajeDeAnsiedadPsiquica;
    this.aSomatica=puntajeDeAnsiedadSomatica;
    this.ansiedadTotal=ansiedadTotal;
}


//Defino las variables de Scope Global
var items = []
var ansiedadPsiquica=0;
var ansiedadSomatica=0;
var puntajeTotalHars=0;


//Variables DOM
const descripcion = document.getElementById("descripcionHars");
const preguntasHars =document.getElementById("pregutasHars");
    //La Sig Variable, es un array con el nombre de las clases de los imputs radio
const clasesRadiosRespuesta = ["gradoAnsiedadI1","gradoAnsiedadI2","gradoAnsiedadI3","gradoAnsiedadI4","gradoAnsiedadI5","gradoAnsiedadI6","gradoAnsiedadI7","gradoAnsiedadI8","gradoAnsiedadI9","gradoAnsiedadI10","gradoAnsiedadI11","gradoAnsiedadI12","gradoAnsiedadI13","gradoAnsiedadI14"]

//Creo los objetos de Scope Global
var paciente = new PlanillaDePaciente();
var resultadosEscalaHars= new EscalaHars();



/*==================FUNCIONES DEL TEST HARS=================*/

//Funcion asignada a un botton para comenzar el test
//Por ahora solo esconde la descripcion y muestra las preguntas
function comenzarHars(){
    descripcion.classList.replace('d-block','d-none');
    preguntasHars.classList.replace('d-none','d-block')

}
function mostrarResultados(){
    respuestasHars();
    harsResultados(resultadosEscalaHars);
}

/*Funcion para que el usuario cargue los datos del paciente*/
//FUERA DE USO POR AHORA
function logPaciente(){
    paciente.nombre = prompt("Ingrese el Nombre y Apellido del paciente");
    paciente.edad = prompt("Edad de " + paciente.nombre);
    paciente.sexo = prompt("Sexo de "+ paciente.nombre);
    paciente.hars = null;
}

/*Este if pregunta si se desea leer las instrucciones */
//FUERA DE USO POR AHORA
function instruccionesHars (quiereInstrucciones) {
    if (quiereInstrucciones == "si"){
        alert("Cada Item representa un Sintoma de estado de Ansiedad. Seleccione para cada ítem la puntuación que corresponda, según su experiencia.\n Las definiciones que siguen al enunciado del ítem son ejemplos que sirven de guía.\n Ingrese en el casillero la cifra que defina mejor la intensidad de cada síntoma en el paciente.\nSiendo 0:Ausente, 1:Leve, 2:Moderado, 3:Grave, 4:Incapacitante.\n Todos los ítemes deben ser puntuados");
    }
    else {
        alert("Perfecto, preparese para comenzar")}

}

//~~ESTA FUNCION RECORRE TODOS LOS IMPUTS Y ASIGNA LOS VALORES A UN ARRAY EN LA POSICION CORRESPONDIENTE~~

function respuestasHars(){
    //Este for recorre un array con los nombre de las 14 clases que van a tener los 5 radios dentro de cada uno de los 14 item
    //y asigna el nombre de cada clase a la variable RadiosRespuesta
    for (i=0;i<clasesRadiosRespuesta.length;i++){
        let radiosRespuesta = document.getElementsByClassName(clasesRadiosRespuesta[i])
        let numerodeItem = i+1 ;//Esta var es solamente para ayudarme en la consola
    
        // Como cada clase posee 5 radios con su nombre, con este for, recorro los 5 imputs
        //y con un if me encargo de capturar el valor del radio que este tildado y agregarlo al array items
        for (j=0; j<5; j++){
            if (radiosRespuesta[j].checked == true){
                console.log("El item numero "+numerodeItem+" tuvo la respuesta "+radiosRespuesta[j].value);
                items[i] = radiosRespuesta[j].value;
            }
        }

        //Este if sirve para validar que todos los items tengan un radio checkeado
        //En caso de no no ser así llamo a la funcion alerta, que abre una ventana de alerta
        if(items[i] == null){
            console.log("El item numero "+numerodeItem+" no tiene respuesta")
            alertaValidacionRadios();
            break
        }
    }
    console.log(items)

    //Aca divido el array item en dos array en base a la categoria de cada pregunta
    //Esto funciono exactamente al revés de lo que esperaba, y fue mas que nada prueba y error
    //Al final asigne las variables al revés y quedó bien jaja
    //Tampoco termino de entender por que despues del splice, se me duplica el elemento 13 del array items (por eso el .pop) 
    let itemsAnsiedadSomatica = items.splice(6,7,items[13]);
    items.pop();
    let itemsAnsiedadPsiquica =items;

    console.log("ansiedadPsi "+ itemsAnsiedadPsiquica)
    console.log("ansiedadSo "+ itemsAnsiedadSomatica)
    debugger
    //Sumo de los items de cada categoría
    for(i=0; i < itemsAnsiedadPsiquica.length; i++){
        ansiedadPsiquica = parseInt(ansiedadPsiquica) + parseInt(itemsAnsiedadPsiquica[i])
    };
    for(i=0; i < itemsAnsiedadSomatica.length; i++){
        ansiedadSomatica = parseInt(ansiedadSomatica) + parseInt(itemsAnsiedadSomatica[i])
    };
    
    //Asigno las propiedades al objeto
    resultadosEscalaHars.aPsiquica=ansiedadPsiquica
    resultadosEscalaHars.aSomatica=ansiedadSomatica
    resultadosEscalaHars.ansiedadTotal=parseInt(ansiedadPsiquica)+parseInt(ansiedadSomatica)
}


//Esta funcion interpreta los resultados para devolver al usuario el tipo de síntomas que tiene el paciente
function harsResultados(objetoEscalaHars){
    debugger
    switch (objetoEscalaHars.ansiedadTotal>-1){
        case objetoEscalaHars.ansiedadTotal == 0:
            alert("El paciente '"+paciente.nombre+"' no presenta sintomás de Ansiedad, sus puntajes son de 0 en todos los items.")
            break;
        case objetoEscalaHars.ansiedadTotal < 17:
            alert("El paciente '"+paciente.nombre+"' resultó con un total de "+objetoEscalaHars.ansiedadTotal+" puntos. \n Los niveles de severidad de Ansiedad son leves.\n"+objetoEscalaHars.aPsiquica+" Puntos corresponden a síntomas de Ansiedad Psíquica"+"\n"+objetoEscalaHars.aSomatica+" Puntos corresponden a síntomas de Ansiedad Somática")
            break;
        case objetoEscalaHars.ansiedadTotal > 17 && objetoEscalaHars.ansiedadTotal < 24:
            alert("El paciente '"+paciente.nombre+"' resultó con un total de "+objetoEscalaHars.ansiedadTotal+" puntos. \n Los niveles de severidad de Ansiedad van de moderados a severos.\n"+objetoEscalaHars.aPsiquica+" Puntos corresponden a síntomas de Ansiedad Psíquica"+"\n"+objetoEscalaHars.aSomatica+" Puntos corresponden a síntomas de Ansiedad Somática")
            break;
        case objetoEscalaHars.ansiedadTotal > 24 && objetoEscalaHars.ansiedadTotal < 56:
            alert("El paciente '"+paciente.nombre+"' resultó con un total de "+objetoEscalaHars.ansiedadTotal+" puntos. \n Los niveles de severidad de Ansiedad son muy severos.\n"+objetoEscalaHars.aPsiquica+" Puntos corresponden a síntomas de Ansiedad Psíquica"+"\n"+objetoEscalaHars.aSomatica+" Puntos corresponden a síntomas de Ansiedad Somática")
            break;
    }
}


//Esta función es para agregar una ventana de alerta en mi HTML cuando falta algun item de responder
function alertaValidacionRadios(){
    const nodoMain = document.getElementById("main");
    let agregarAlert= document.createElement('div');

    agregarAlert.classList.add("alert","alert-danger","alert-dismissible","fade","show","alerta");
    agregarAlert.setAttribute('role', 'alert');
    agregarAlert.innerHTML = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><strong>Quedan Items sin responder!</strong>';

    nodoMain.appendChild(agregarAlert)

}